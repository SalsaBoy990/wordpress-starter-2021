<?php

/**
 * Plugin Name: reactwp-blocks
 * Plugin URI: https://gitlab.com/guland/react-wp-gutenberg
 * Description: React block for my reactwp theme
 * Author: András Gulácsi
 * Author URI: https://github.com/SalsaBoy990
 */

if (!defined('ABSPATH')) {
  exit;
}


function reactwp_blocks_categories($categories, $post)
{
  return array_merge($categories, array(
    array(
      'slug' => 'reactwp-category',
      'title' => __('ReactWP theme category', 'reactwp-blocks'),
      'icon' => 'wordpress',
    )
  ));
}

add_filter('block_categories', 'reactwp_blocks_categories', 10, 2);

/**
 * @param string $block
 * @param array $options
 * 
 * @return void
 */
function reactwp_blocks_register_block_type(string $block, array $options = [])
{
  register_block_type(
    'reactwp-blocks/' . $block,
    array_merge(
      array(
        'editor_script' => 'reactwp-blocks-editor-script',
        'script' => 'reactwp-blocks-script',
        'style' => 'reactwp-blocks-style',
        'editor_style' => 'reactwp-blocks-editor-style'
      ),
      $options
    )
  );
}

add_action('init', 'reactwp_blocks_register');

/**
 * @return void
 */
function reactwp_blocks_register()
{
  /*wp_register_script(
    'reactpw-blocks-firstblock-editor-script',
    plugins_url('dist/editor.js', __FILE__),
    array('wp-blocks', 'wp-i18n', 'wp-element')
  );*/

  // --------------------------------------------
  // Admin script bundle
  wp_register_script(
    'reactwp-blocks-editor-script',
    plugins_url('dist/editor.js', __FILE__),
    array('wp-blocks', 'wp-i18n', 'wp-element', 'wp-editor', 'wp-block-editor', 'wp-components', 'lodash')
  );

  // Frontend script bundle
  wp_register_script(
    'reactwp-blocks-script',
    plugins_url('dist/script.js', __FILE__),
    array('jquery')
  );

  // --------------------------------------------
  // Admin css bundle
  wp_register_style(
    'reactwp-blocks-editor-style',
    plugins_url('dist/editor.css', __FILE__),
    array('wp-edit-blocks')
  );

  // Frontend css bundle
  wp_register_style(
    'reactwp-blocks-style',
    plugins_url('dist/style.css', __FILE__),
    array()
  );

  // --------------------------------------------
  // REGISTER ALL CUSTOM GUTENBERG BLOCKS
  // --------------------------------------------
  reactwp_blocks_register_block_type('firstblock');
  reactwp_blocks_register_block_type('secondblock');
}
